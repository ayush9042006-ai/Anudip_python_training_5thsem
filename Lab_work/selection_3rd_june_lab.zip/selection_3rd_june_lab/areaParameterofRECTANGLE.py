# Program to calculate Area and Perimeter of a Rectangle

length = float(input("Enter length: "))
if length < 0:
    print("Length cannot be negative.")
    exit()

width = float(input("Enter width: "))
if width < 0:
    print("Width cannot be negative.")
    exit()

area = length * width
perimeter = 2 * (length + width)

print("Area of rectangle =", area)
print("Perimeter of rectangle =", perimeter)
